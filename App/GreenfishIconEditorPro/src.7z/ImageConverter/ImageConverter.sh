#!/bin/bash
mono $(dirname "$0")/bin/Debug/ImageConverter.exe "$@"
