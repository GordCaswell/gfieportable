#!/bin/bash
python make_pascalscript_import.py
